# Criando a primeira função do código.
def cadastrar_colheita():
    # Função de menu
    print("\n" + "="*40)
    print("       NOVA COLHEITA")
    print("="*40)
    
    try:
        # Nome do voluntário.
        voluntario = input("\nNome do voluntário: ").strip()
        if not voluntario:
            print("O nome do voluntário não pode estar vazio.")
            return None
        
        # Data da colheita com validação usando as funções.
        print("\nData da colheita:")

        while True:
            try:
                dia_colheita = int(input("Dia da colheita: "))
                if 1 <= dia_colheita <= 31:
                    break
                else:
                    print("Dia inválido.")
            except ValueError:
                print("Digite um número válido para o dia.")
        
        while True:
            try:
                mes_colheita = int(input("Mês da colheita: "))
                if 1 <= mes_colheita <= 12:
                    break
                else:
                    print("Mês inválido.")
                
            except ValueError:
                print("Digite um número válido para o mês.")
        
        while True:
            try:
                ano_colheita = int(input("Ano da colheita: "))
                if 2000 <= ano_colheita <= 2030:
                    break
                else:
                    print("Ano inserido inválido")

            except ValueError:
                print("O sistema aceita apenas anos no intervalo de 2000 a 2030.")

        # Informações dos Legumes.
        print("\nInformações da colheita:")
        nome_colheita = input("Nome do legume: ").strip()
        if not nome_colheita:
            print("O nome do legume não pode estar vazio.")
            return None

        # Validação do peso
        while True:
            try:
                peso_colheita = float(input("Peso do legume (Kg): "))
                if peso_colheita > 0:
                    break
                else:
                    print("Valor inválido, o peso da colheita não pode ser 0.")
            except ValueError:
                print("Digite um valor numérico válido para o peso.")
        
        # Dicionário da colheita.
        colheita = {
            'voluntario': voluntario,
            'legume': nome_colheita,
            'peso': peso_colheita,
            'dia': dia_colheita,
            'mes': mes_colheita,
            'ano': ano_colheita
        }

        print("\nColheita registrada com sucesso!")

        # Verificação de peso, para caso seja necessário um caminhão.
        if peso_colheita >= 50:
            print("Colheita acima de 50 kg, caminhão necessário para a coleta.")

        return colheita
    
    except KeyboardInterrupt:
        print("\n\nOperação cancelada pelo usuário.")
        return None
    except Exception as e:
        print(f"\nErro inesperado: {e}")
        return None


# Função de relatório.
def exibir_relatorio(colheitas):
    # Menu de relatorio.
    print("\n" + "="*50)
    print("          RELATÓRIO COMPLETO")
    print("="*50)

    # Validação de colheitas (Se houver).
    if not colheitas:
        print("\nNenhuma colheita foi registrada.")
        print("Registre uma colheita selecionando '1'.\n")
        return
    
    print("\nLISTA DE COLHEITAS REGISTRADAS:")
    print("-"*50)

    # Variável para o peso (total registrado).
    total_peso = 0

    # Loop for para percorrer todas as colheitas registradas.
    for i, colheita in enumerate(colheitas, 1):
        print(f"\n[{i}] Voluntário: {colheita['voluntario']}")
        print(f"    Legume: {colheita['legume']}")
        print(f"    Peso: {colheita['peso']:.2f} Kg")
        print(f"    Data: {colheita['dia']:02d}/{colheita['mes']:02d}/{colheita['ano']}")

        total_peso += colheita['peso']

    print("\n" + "-"*50)
    print("\nRESUMO FINAL:")
    print(f"Total de colheitas registradas: {len(colheitas)}")
    print(f"PESO TOTAL ACUMULADO: {total_peso:.2f} Kg")
    
    # Validação de peso.
    media_peso = total_peso / len(colheitas)
    print(f"MÉDIA DE PESO POR COLHEITA: {media_peso:.2f} Kg")
    
    maior_colheita = max(colheitas, key=lambda x: x['peso'])
    menor_colheita = min(colheitas, key=lambda x: x['peso'])
    
    print(f"\nMAIOR COLHEITA: {maior_colheita['legume']} - {maior_colheita['peso']:.2f} Kg")
    print(f"MENOR COLHEITA: {menor_colheita['legume']} - {menor_colheita['peso']:.2f} Kg")


def exibir_menu():
    # Finalmente o menu.
    print("\n" + "-"*40)
    print("         MENU PRINCIPAL")
    print("-"*40)
    print("   1. Registrar nova colheita")
    print("   2. Ver relatório completo")
    print("   3. Sair do programa")
    print("-"*40)


def main():
    # Chamada da lista já criada com def anteriormente.
    colheitas = []

    # Titulo :}
    print("\n" + "="*50)
    print("          AGROTECH MONITOR - COLHEITA")
    print("="*50 + "\n")

    # Loop do programa.
    while True:
        exibir_menu()
        
        try:
            user = input("\nDigite sua opção (1/2/3): ").strip()
            
            # Opção 1 - Registro de colheita.
            if user == "1":
                nova_colheita = cadastrar_colheita()
                if nova_colheita:
                    colheitas.append(nova_colheita)
            
            # Opção 2 - Ver relatório das colheitas
            elif user == "2":
                exibir_relatorio(colheitas)
            
            # Opção 3 - Sair do programa.
            elif user == "3":
                print("\n" + "="*50)
                print("       PROGRAMA FINALIZADO")   
                print("="*50 + "\n")
                break
            
            # Lógica de validação.
            else:
                print("\nOpção inválida! Por favor, digite 1, 2 ou 3.")
        
        except KeyboardInterrupt:
            print("\n\nPrograma interrompido pelo usuário.")
            break
        except Exception as e:
            print(f"\nErro inesperado: {e}")
            print("Por favor, tente novamente.")


# Ponto de entrada do programa.
if __name__ == "__main__":
    main()