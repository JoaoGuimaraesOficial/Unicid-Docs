# Lista onde será armazenadas as colheitas.
colheitas = []

# Titulo.
print("\n" + "="*50)
print("          AGROTECH MONITOR - COLHEITA")
print("="*50 + "\n")

# Dentro do while.
while True:
    print("\n" + "-"*40)
    print("         MENU PRINCIPAL")
    print("-"*40)
    print("   1. Registrar nova colheita")
    print("   2. Ver relatório completo")
    print("   3. Sair do programa")
    print("-"*40)

    user = input("\nDigite sua opção (1/2/3): ")

    # Opção 1 - registro de colheita.
    if user == "1":
        print("\n" + "="*40)
        print("       NOVA COLHEITA")
        print("="*40)

        # Informações do voluntário.
        voluntario = input("\n Nome do voluntário: ")

        # Data da colheita.
        print("\nData da colheita:")
        dia_colheita = int(input("Dia: "))
        mes_colheita = int(input("Mês: "))
        ano_colheita = int(input("Ano: "))

        # Informações do legume
        print("\nInformações da colheita:")
        nome_colheita = input("Nome do legume: ")

        # Validação do peso
        peso_colheita = float(input("Peso (Kg): "))
        while peso_colheita <= 0:
            print("Valor inválido! O peso deve ser maior que zero.")
            peso_colheita = float(input("Peso (Kg): "))
        
        # Dicionario de armazenamento da colheita.
        colheita = {
            'voluntario': voluntario,
            'legume': nome_colheita,
            'peso': peso_colheita,
            'dia': dia_colheita,
            'mes': mes_colheita,
            'ano': ano_colheita
        }

        # Função que armazena as informações da colheita.
        colheitas.append(colheita)

        # Apenas uma resposta visual para que o usuário possa entender que a interação deu certo.
        print("\nColheita registrada com sucesso!")
        
         # Verificação sob o peso da colheita.
        if peso_colheita >= 50:
            print("*** Colheita acima de 50 kg, caminhão necessário para a coleta. ***")

    # Opção 2 - Ver relatorio completo.
    elif user == "2":
        print("\n" + "="*50)
        print("          RELATÓRIO COMPLETO")
        print("="*50)

        # Verifica se há colheitas já registradas.
        if len(colheitas) == 0:
            print("\nNenhuma colheita registrada ainda!")
            print("Use a opção 1 para registrar uma colheita.\n")
        else:
            print("\nLISTA DE COLHEITAS REGISTRADAS:")
            print("-"*50)

            # variável que armazena o peso total das colheitas.
            total_peso = 0
            
            # Interação que percorre cada item da lista.
            for i, colheita in enumerate(colheitas, 1):
                print(f"\n[{i}] Voluntário: {colheita['voluntario']}")
                print(f"Legume: {colheita['legume']}")
                print(f"Peso: {colheita['peso']:.2f} Kg")
                print(f"Data: {colheita['dia']:02d}/{colheita['mes']:02d}/{colheita['ano']}")

                total_peso += colheita['peso']

            print("\n" + "-"*50)
            print(f"\nRESUMO FINAL:")
            print(f"Total de colheitas registradas: {len(colheitas)}")
            print(f"PESO TOTAL ACUMULADO: {total_peso:.2f} Kg")       

    # Saída de loop.
    elif user == "3":
        print("\n" + "="*50)
        print("       PROGRAMA FINALIZADO")   
        print("="*50 + "\n")
        break     

    else:
        print("Insirá um valor válido para iniciar o programa! (1, 2 ou 3).")

# Loop Finalizado - FINALGORITMO.