# Código do projeto da disciplina de "Programação de Computadores" em python. (Dados da Colheita (Backend))

# Titulo.
print("\n" + "="*50)
print("          AGROTECH MONITOR - COLHEITA")
print("="*50 + "\n")

# Dentro do while.
while True:
    
    # Informações iniciais.
    print("Identifique o voluntário.")
    voluntario = input("Nome do voluntario: ")

    # Registro sobre o dia, mês e ano da colheita.
    print("Registre a data da colheita.")
    dia_colheita = int(input("Dia da colheita: "))
    mes_colheita = int(input("Mês da colheita: "))
    ano_colheita = int(input("Ano da colheita: "))

    # Informações do item colhido pelo voluntário.
    print("Registre as informações da colheita.")
    nome_colheita = input("Insira o nome do legume colhido: ")
    
    peso_colheita = float(input("Insira o peso do legume colhido: "))
    while peso_colheita < 1:
        print("Valor inserido 0 ou negativo. Favor, coloque um valor valido!")
        peso_colheita = float(input("Insira o peso do legume colhido: "))

    # Fase de lógica - print com as informações já funcional com registro em tela.
    print(f"\nO voluntário {voluntario} colheu {peso_colheita:.2f} Kg de {nome_colheita}.")
    print(f"Data da colheita: {dia_colheita:02d}/{mes_colheita:02d}/{ano_colheita}")
    if peso_colheita >= 50:
        print("*** Colheita acima de 50 kg, caminhão necessário para a coleta. ***")
    print("\n" + "="*50)

    print("digite 'S' para continuar, ou 'N' para finalizar.")
    user = input("Digite aqui: ")
    if user == "N" or user == "n":
        break
    elif user == "S" or user == "s":
        print("<<<Restart>>>")
        print("\n" + "="*50)

# Fora do Loop while.
print("="*50 + "\n")
print("Fora do Loop")