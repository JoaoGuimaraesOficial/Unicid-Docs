print("Comparação de Dois Números.")

userInsert1 = int(input("Insira o primeiro número: "))
userInsert2 = int(input("Insira o segundo número: "))

if userInsert1 > userInsert2:
    print("O primerio número é maior que o segundo.")
elif userInsert2 > userInsert1:
    print("O segundo número é maior que o primeiro.")
else:
    print("Os números são iguais.")