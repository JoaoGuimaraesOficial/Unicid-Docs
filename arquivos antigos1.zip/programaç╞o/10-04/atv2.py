print("Validação de média.")

nota1 = int(input("Insira a primeira nota: "))
nota2 = int(input("Insira a segunda nota: "))
nota3 = int(input("Insira a terceira nota: "))
nota4 = int(input("insira a quarta nota: "))

media = (nota1+nota2+nota3+nota4) / 4

if media >= 6:
    print("Aluno aprovado.")
elif 4 < media < 6:
    print("Fazer recuperação.")
else:
    print("Aluno reprovado")