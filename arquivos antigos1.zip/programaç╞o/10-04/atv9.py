print("Classificação de Idade (Categorias)")

userInsert = int(input("Insira sua idade para validar sua categoria: "))

if 4 < userInsert < 11:
    print("Atleta Infantil.")
elif 10 < userInsert < 18:
    print("Atleta Juvenil.")
elif userInsert < 5:
    print("Idade invalida.")
else:
    print("Atleta Sênior.")
