print("*** Validação de Idade ***")

userInsert = int(input("Insira sua Idade: "))

if userInsert < 18:
    print("Você tem menos de 18 anos, o usuário ainda é menor de idade.")
else:
    print("Você tem mais de 18 anos, o usuário é maior de idade.")