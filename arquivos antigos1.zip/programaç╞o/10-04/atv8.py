print("Verificação de Saldo Bancário")

saldo = 500
print("Seu saldo e de R$ 500 reais")

userInsert = int(input("Insira um valor para sacar: "))
saldo = saldo - userInsert

if saldo >= 0:
    print("Transação aceita.")
    print("Saldo atual = ", saldo)
else:
    print("Transação Cancelada, saldo insuficiente.")