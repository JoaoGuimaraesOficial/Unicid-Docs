print("Reajuste Salarial (Baseado em Vendas)")

userInsert = int(input("Insira a quantidade de sistemas vendidos: "))

if userInsert < 10:
    print("Reajuste salarial de R$50,00")
else:
    print("Resjuste salarial de R$80,00")