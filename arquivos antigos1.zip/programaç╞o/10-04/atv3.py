print("Calculadora de números Impar/ Par")

while True:
    userInsert = int(input("Insira o número (digite 0 para parar): "))

    if userInsert == 0:
        break

    if userInsert % 2 == 0:
        print("O número inserido é Par")
    else:
        print("O número Inserido é Impar")

print("Fora do Loop While")