print("Cálculo de Desconto de INSS.")

userInsert = int(input("Insira o seu salario para calculo do INSS: "))

if userInsert >= 2000:
    print("O desconto do INSS e de 11%")
    userInsert = userInsert + (userInsert - 0.11)
    print(userInsert)
else:
    print("O desconto do INSS e de 9%")
    userInsert = userInsert + (userInsert - 0.09)
    print(userInsert)

