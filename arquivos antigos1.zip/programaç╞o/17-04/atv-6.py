n = int(input("Digite a quantidade de elementos da sequência de Fibonacci: "))

fibonacci = []
a, b = 0, 1

for i in range(n):
    fibonacci.append(a)
    a, b = b, a + b

print(f"Os {n} primeiros elementos da sequência de Fibonacci são:")
print(fibonacci)