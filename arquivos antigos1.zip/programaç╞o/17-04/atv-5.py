print("Média de idades.")
print("Insira idades de várias pessoas para calcular a média.")

quantP = 0
idadeP = 0

while True:
    insert = int(input("Insira a idade: "))
    idadeP = idadeP + insert
    quantP = quantP + 1

    print("*** Digite 999 para sair ***")
    valid = int(input("Isert: "))
    if valid == 999:
        print("Fora do loop")
        break
    else:
        print("Dentro do loop")

media = idadeP / quantP

print(quantP, " pessoas foram registradas.")
print("A média de idade é igual à: ", media)