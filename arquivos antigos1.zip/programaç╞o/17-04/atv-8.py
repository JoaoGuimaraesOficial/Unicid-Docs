print("Calculadora")

result = 0

while True:
    print("Digite dois números para o calculo.")

    num1 = int(input("Primeiro número: "))
    num2 = int(input("Segundo número: "))

    print("=" * 30)
    print("         MENU")
    print("=" * 30)
    print("1 - Somar")
    print("2 - Multiplicar")
    print("3 - Inserir novos números")
    print("4 - Encerrar programa")
    print("=" * 30)

    while True:
        insert = int(input("Insira aqui: "))

        if insert != 1 and insert != 2 and insert != 3 and insert != 4:
            print("Número inválido.")
        else:
            break

    if insert == 1:
        print("Soma selecionada.")
        result = num1 + num2
        print(result)

    elif insert == 2:
        print("Multiplicação selecionada.")
        result = num1 * num2
        print(result)
    
    elif insert == 3:
        print("Reset da calculadora.")

    elif insert == 4:
        print("Sainda da calculadora")
        break

print("Fora do loop")