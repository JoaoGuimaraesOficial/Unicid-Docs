print("Validação de Dados")
print("Insira um número de 0 a 10 para validação")

userInsert = int(input("Digite o número: "))

while userInsert > 11:
    print("Digite um número valido!")
    userInsert = int(input("Digite o número: "))
print("O número ", userInsert, " se encaixa!")