print("Somador Infinito (quase)")

sumNumbers = 0
userInsert = int(input("Digite aqui 1 para iniciar: "))
print("digite 0 para cancelar")

while userInsert != 0:
    userInsert = int(input("Digite aqui: "))
    sumNumbers = sumNumbers + userInsert
print("A soma dos números inseridos é igual à: ", sumNumbers)