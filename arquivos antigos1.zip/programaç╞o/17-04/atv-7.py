print("SIMULADOR DE CAIXA ELETRÔNICO")

cedulas = [50, 20, 10, 1]

while True:
    try:
        valor = int(input("\nDigite o valor que deseja sacar (R$): "))
        
        if valor <= 0:
            print("Valor inválido! Digite um valor positivo.")
            continue

        print(f"\n{'=' * 40}")
        print(f"Saque de R$ {valor:.2f}")
        print(f"{'=' * 40}")
        
        valor_restante = valor
        resultado = {}
        
        for cedula in cedulas:
            if valor_restante >= cedula:
                quantidade = valor_restante // cedula
                resultado[cedula] = quantidade
                valor_restante -= quantidade * cedula
        
        print("\nCédulas entregues:")
        print("-" * 40)
        for cedula, quantidade in resultado.items():
            print(f"R$ {cedula:>2}: {quantidade:>3} cédula(s)")
        
        print("-" * 40)
        print(f"Total sacado: R$ {valor - valor_restante:.2f}")
        
        continuar = input("\nDeseja realizar outro saque? (s/n): ").lower()
        if continuar != 's':
            print("\nObrigado por usar nosso caixa eletrônico!")
            break
            
    except ValueError:
        print("Erro! Digite apenas números inteiros.")