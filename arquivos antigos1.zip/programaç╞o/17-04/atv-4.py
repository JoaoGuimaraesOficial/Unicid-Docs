print("Tabuada")

while True:
    print("Digite um número para ver sua tabuada.")
    num = int(input("Digite o número: "))
    valor = 10

    while valor > 0:
        print(num * valor)
        valor = valor - 1
    
    print("digite 'S' para continuar, ou 'N' para finalizar.")
    user = input("Digite aqui: ")
    if user == "N":
        break
print("Atvidade cancelada.")