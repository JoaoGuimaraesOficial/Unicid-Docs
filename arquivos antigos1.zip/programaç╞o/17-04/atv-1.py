print("Digite um número para contagem regressiva.")

userInsert = int(input("Digite aqui: "))
while userInsert != 0:
    print(userInsert)
    userInsert = userInsert - 1
print("BOOOM!")