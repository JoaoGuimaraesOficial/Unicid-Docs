# Faça um programa que solicite ao usuário um número inteiro (n). Este número deverá ser pesquisado na lista abaixo. Ao final apresentar as mensagens: “n encontrado na posição x.” ou “n não encontrado.”

list = [12, 15, 7, 9, 27, 34]

print("Digite um número para pesquisar na lista.")

user = int(input("Digite: "))

if user in list:
    position = list.index(user)
    print(f"{user} encontrado na posição {position}.")
else:
    print(f"{user} não encontrado.")