# Faça um programa que solicite ao usuário digitar números para criação de uma lista. Quando ele quiser terminar de preencher a lista deverá digitar 0 (zero)

numeros = []

while True:
    numbers = int(input("Digite números para a lista: "))
    
    if numbers == 0:
        break
    numeros.append(numbers)
    print("Digite 0 para sair.")

print("Os elementos da lista são: ", numeros)