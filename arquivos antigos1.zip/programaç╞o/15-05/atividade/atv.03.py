# Faça um programa que percorra duas listas e gere uma terceira sem elementos repetidos. As duas primeiras listas o usuário deverá digitar os valores, quando ele quiser terminar de preencher a lista deverá digitar 0 (zero).

lista1 = []
lista2 = []
lista3 = []

print("Preencha a primeira lista (digite 0 para terminar):")
while True:
    valor = int(input("Digite um valor: "))
    
    if valor == 0:
        break
    
    lista1.append(valor)

print("\nPreencha a segunda lista (digite 0 para terminar):")
while True:
    valor = int(input("Digite um valor: "))
    
    if valor == 0:
        break
    
    lista2.append(valor)

# Junta as listas sem repetir elementos
for item in lista1:
    if item not in lista3:
        lista3.append(item)

for item in lista2:
    if item not in lista3:
        lista3.append(item)

print("\nLista 1:", lista1)
print("Lista 2:", lista2)
print("Lista 3 sem repetidos:", lista3)