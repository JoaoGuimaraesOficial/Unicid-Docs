numbers = [1,2,3,4,5,6,7,8,9,10]
indice = 0

while indice < len(numbers):
    print("O elemento presente no indice %d é igual à: %d"%(indice, numbers[indice]))
    indice += 1