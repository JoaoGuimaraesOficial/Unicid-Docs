vocabulario = ["iteração","seleção","controle"]
numeros = [17, 123]
lista_mista = ["Ola", 2.0, 5*2, [10, 20]]

print(numeros)
print(lista_mista)

nova_lista = [numeros, vocabulario]
print(nova_lista)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    