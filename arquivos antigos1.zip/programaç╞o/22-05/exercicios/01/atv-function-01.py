def validacao (a, b):
    if a > b:
        return a
    else:
        return b

print(validacao(9, 9))