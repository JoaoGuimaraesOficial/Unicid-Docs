def area_quadrado (a):
    return a * a

area1 = area_quadrado(4)
print(area1)

area2 = area_quadrado(9)
print(area2)

area3 = area_quadrado(10)
print(area3)
