def vogal(caractere):
    return caractere.lower() in "aeiou"

print(vogal("a")) 
print(vogal("b")) 
print(vogal("E"))  
print(vogal("v"))  
print(vogal("O"))  
print(vogal("d"))  
