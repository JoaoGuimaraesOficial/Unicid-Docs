def maximo (a, b ,c):
    if a > b and a > c:
        return a
    elif b > a and b > c:
        return b
    else:
        return c

retorno = maximo(45, 12, 44)
print(retorno)

retorno1 = maximo(9, 12, 10)
print(retorno1)

retorno2 = maximo(6, 7, 8)
print(retorno2)