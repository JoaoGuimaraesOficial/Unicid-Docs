def baskara (a, b ,c):
    delta = (b * b)- (4 * a * c)
    
    if delta < 0:
        return "Não existem raízes reais"

    x1 = (-b + (delta ** 0.5)) / (2 * a)
    x2 = (-b - (delta ** 0.5)) / (2 * a)
    
    return x1, x2

a1 = baskara(1, 7, 10)
print(a1)