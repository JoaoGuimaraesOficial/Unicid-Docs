def multiplica(x,y,z):
    return(x * y * z)
#
resultado = multiplica(1,2,3)
print("Resultado:", resultado)
#
resultado = multiplica(2,4,6)
print("Resultado:", resultado)