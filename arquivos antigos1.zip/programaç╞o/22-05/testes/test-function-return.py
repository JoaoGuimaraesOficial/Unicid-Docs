def soma(a,b):
    return (a + b)

def subtracao(a,b):
    return (a - b)

def divisao(a,b):
    return (a / b)

def multiplicacao(a,b):
    return (a * b)

print("Soma:", soma(10, 9))
print("Subtração:",subtracao(45, 40))
print("Divisão:",divisao(500, 5))
print("Multiplicação:",multiplicacao(80, 6))