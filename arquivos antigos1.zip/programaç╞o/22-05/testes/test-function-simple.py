def calculo_soma (a, b):
    print("A soma dos valores é:", a + b),

calculo_soma(4, 8)

def calculo_mult (a, b):
    print("A multiplicação dos valores é:", a * b),

calculo_mult(10, 3)

def calculo_divi (a, b):
    print("A divisão dos valores é:", a / b),

calculo_divi(20, 4)

def calculo_subt (a, b):
    print("A subtração dos valores é:", a - b),

calculo_subt(80, 45)