print("Antes da troca:")
a = 10
b = 20
c = 0

print("Valor A =", a, "valor B =", b)

print("Depois da troca:")
c = a
a = b
b = c

print("Valor A =", a, "valor B =", b)